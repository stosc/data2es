#!/usr/bin/env python3
#-*- coding:utf-8 -*-

#############################################
# File Name: source_data_provider.py
# Author: stosc
# Mail: stosc@sidaxin.com
# Created Time:  2020-2-8 19:17:34
#############################################