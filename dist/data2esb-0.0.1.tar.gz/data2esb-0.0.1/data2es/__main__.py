#!/usr/bin/env python3
#-*- coding:utf-8 -*-

#############################################
# File Name: __mian__.py
# Author: stosc
# Mail: stosc@sidaxin.com
# Created Time:  2020-2-8 19:17:34
#############################################
from data2es import maind

if __name__=="__main__":
    maind.run()